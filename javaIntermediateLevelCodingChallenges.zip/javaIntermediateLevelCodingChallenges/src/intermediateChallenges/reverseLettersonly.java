package helloWorld;
import java.util.ArrayList;
public class reverseLettersonly {
public static void main(String[] args) {
	     String number_string1  = "b98s76X87z";
		String number_string  = "b98s76X87z";
		ArrayList<Integer> index_tracker_int = new ArrayList<Integer>();	
		ArrayList index_tracker_str = new ArrayList<Integer>();	
		//String number_string = String.valueOf(number);
		String empty_string = "";
		String empty_string_reverse = "";
        for(int k = 0; k  < number_string.length(); k++) {
			if(Character.isLetter(number_string.charAt(k))) {
				//index_tracker_int.add(k);
        	   empty_string += number_string.charAt(k);
			}else {
				index_tracker_int.add(k);
				number_string = number_string.replace(number_string.charAt(k),'-');
				 empty_string += '-';
			}
			
		}
		
		for(int k = empty_string.length()-1; k  >= 0; k--) {
			empty_string_reverse += empty_string.charAt(k);
		}
		
		System.out.println(empty_string);
		System.out.println(empty_string_reverse);
		StringBuilder sb = new StringBuilder(empty_string_reverse);
		for(Integer num:index_tracker_int) {
			
			if(empty_string_reverse.charAt(num)=='-') {
				sb.setCharAt(num,number_string1.charAt(num));
				System.out.println("YES");
				//empty_string_reverse = empty_string_reverse.replace('-',number_string1.charAt(num));
			}
			//empty_string_reverse = empty_string_reverse.replace('-',number_string1.charAt(num));
			//System.out.println(empty_string_reverse);
		}
		System.out.println("String: "+sb);
		System.out.println(empty_string_reverse);
	}

}
