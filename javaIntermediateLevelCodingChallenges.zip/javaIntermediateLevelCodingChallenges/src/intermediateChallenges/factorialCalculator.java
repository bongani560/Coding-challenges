//Author: Bongani Radebe
//Challenge: A factorial evaluator. Limit is on very long factorial results
package helloWorld;

public class factorialCalculator {
	public static void main(String[] args) {
		int number = 6; //Sample number
		int product = 1; 
		for(int j = 1; j <= number; j++) {
			product *= j; // multiply every value from 1 going up to the number
		}
		System.out.println("factorial of "+number+" is: "+product);
	}

}
