package helloWorld;

import java.awt.List;
import java.util.ArrayList;

public class anagramGame {
	public static void main(String[] args) {
		ArrayList word_list1 = new ArrayList<String>();
		ArrayList word_list2 = new ArrayList<String>();
		ArrayList letter_match_count = new ArrayList<String>();
		String word1 = "Hello";
		String word2 = "Helol";
		//String[] word_list = word.split(" ");
		for(int k = 0; k  < word1.length(); k++) {
			//System.out.println("H"+word.length());
			//System.out.println(word.charAt(k));
			word_list1.add(word1.charAt(k));
		
		}
		
		for(int k = 0; k  < word2.length(); k++) {
			//System.out.println("H"+word.length());
			//System.out.println(word.charAt(k));
			word_list2.add(word2.charAt(k));
		
		}
		int counter = 0;
		int removal_counter = 0;
		if(word_list2.size() == word_list1.size()) { 
			for(int k = 0; k  < word1.length(); k++) {
				for(int j = 0; j  < word1.length(); j++) {
				if(word1.charAt(k)==word2.charAt(j)) { 
					word2 = word2.replace (word2.charAt(j),'-');
					System.out.println("word2: "+word2);
					System.out.println("j: "+j); 
					System.out.println(word1.charAt(k));
					counter++;
				}
				}
			}
			 
		}else {
			System.out.println("These two words are not anagrams of each other");
		}
		System.out.println(word_list1);
		System.out.println(word_list2);
		System.out.println("number of matching letters is: "+counter);
	}
}
