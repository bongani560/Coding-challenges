package helloWorld;

//Author: Bongani Radebe
//Challenge: Code that rearranges arraylist elements in ascending order
import java.util.ArrayList;

public class sortArray {
	public static void main(String[] args) {
		ArrayList<Integer> sample_list = new ArrayList<Integer>();
		sample_list.add(0);
		sample_list.add(9);
		sample_list.add(1);
		sample_list.add(18);
		sample_list.add(16);
		sample_list.add(2);
		sample_list.add(1);
		sample_list.add(0);
		int j = 0; 
		while(j + 1 <= sample_list.size() - 1) { //true as long as the indexing stays within length bound
				
			if(sample_list.get(j) > sample_list.get(j+1)) { //if preceding number is greater than that follows
				int x = sample_list.get(j+1);
				int y = sample_list.get(j);
				sample_list.set(j, x); 
				sample_list.set(j+1, y);
				j = 0; //reset loop and search again until no other instance found
				
			}
			j++;
			}
			 
		System.out.println("list: "+sample_list);
	}
		

}

