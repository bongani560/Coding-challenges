package helloWorld;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class wordFrequency {
	public static void main(String[] args) {
		ArrayList<String> word_list = new ArrayList<String>();
		ArrayList<Integer> frequency_counter = new ArrayList<Integer>();
		String sentence = "testing and testing word frequency.Yes we're testing";
		String[] sentence_split = sentence.split("[ ,\\.]+");
		int i = 0;
		while(i < sentence_split.length) {
			 word_list.add(sentence_split[i]);
			 i++;
		}
		i = 0;
		for(int j = 0; j <= word_list.size() - 1; j++) {
			for(int k = 0; k <= word_list.size() - 1; k++) {
				if(word_list.get(j).equals(word_list.get(k))) {
					i++;
				}
				
			}
			frequency_counter.add(i);
			i = 0;
			}
		Map<String,Integer> dictionary = new HashMap<>();
		
		for(int m = 0; m <= word_list.size() - 1; m++) {
		dictionary.put(word_list.get(m),frequency_counter.get(m));
		}
		
		System.out.println("frequency_counter: "+frequency_counter);
		System.out.println("dictionary: "+dictionary);
		for(String key: dictionary.keySet()) {
			System.out.println("\""+key+"\" appears "+dictionary.get(key)+" time(s)");
		}
	}
	
	

}
