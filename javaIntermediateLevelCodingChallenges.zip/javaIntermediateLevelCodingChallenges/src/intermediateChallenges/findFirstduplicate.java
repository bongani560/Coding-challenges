//Author: Bongani Radebe
//Challenge: Detrmine which world is a duplicate in a sentence 
package helloWorld;
import java.util.*;
public class findFirstduplicate {
	public static void main(String[] args) {
		ArrayList<String> sentence_list = new ArrayList<String>(); //string converted to a list
		ArrayList<String> sentence_list_copy = new ArrayList<String>(); //A copy of the list that ought to stay unaltered
		ArrayList<Integer> index_list = new ArrayList<Integer>(); //List containing duplicate indices
		String sentence = "helldo 2tr people of earth there of hello"; //sample sentence
		String[] word_list = sentence.split(" ");//Convert sentence to array. Use just space delimiter for now
	
		for(int j = 0; j <= word_list.length - 1; j++) { //Chuck array elements into arraylists
			
			sentence_list.add(word_list[j]);
			sentence_list_copy.add(word_list[j]);
			
			}
		
		for(int j = 0; j <= sentence_list.size() - 1; j++) {
			for(int k = 0; k <= sentence_list.size() - 1; k++) {
			if(sentence_list.get(j).equals(sentence_list.get(k)) && j != k) { //if duplicate found add index into index_list
			index_list.add(k);
			
			sentence_list.set(k, String.valueOf(k)); 
			}
		}
		
		
	}
		if(index_list.size() > 0) { //if duplicates do indeed exist
       int smallestIndex  = Collections.min(index_list); //get value of smallest index
		System.out.println("first duplicate is the word: "+sentence_list_copy.get(smallestIndex));
		}else {
			System.out.println("No duplicates found");
		}
}
}


