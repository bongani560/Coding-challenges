package helloWorld;
import java.util.*;
public class minimumFinder {
	public static void main(String[] args) {
		ArrayList<Integer> number_list = new ArrayList<Integer>();
		number_list.add(0);
		number_list.add(9);
		number_list.add(1);
		number_list.add(18);
		number_list.add(16);
		number_list.add(2);
		number_list.add(-2);
		int counter = 0;
		if(number_list.size() > 1) {
		while(counter + 1 <  number_list.size()) {
			
			if(number_list.get(counter) < number_list.get(counter + 1)) {
				number_list.remove(counter+1);//delete the bigger element and reset counter
				counter = 0;
			}if(number_list.get(counter) > number_list.get(counter + 1)) {
				number_list.remove(counter);//delete the bigger element and reset counter
				counter = 0;
			}
			counter++;
		} //Eventually the list will be left with the two smallest values because while loop cant go further
		//than counter + 1
		counter = 0; //reset counter to zero to compare the two remaining values
		if(number_list.size() > 1) {
		if(number_list.get(counter) < number_list.get(counter + 1)) {
			number_list.remove(counter+1);//delete the bigger element and reset counter
		}
		
		}if(number_list.size() > 1) {
			if(number_list.get(counter) > number_list.get(counter + 1)) {
		
			number_list.remove(counter);//delete the bigger element and reset counter
		}
		}
	}else {
		System.out.println("List is either empty or doesnt have a minimum of 2 elements");
	}
		System.out.println("Number list: "+number_list);
		System.out.println("Minimum value: "+number_list.get(counter));
	}

}
