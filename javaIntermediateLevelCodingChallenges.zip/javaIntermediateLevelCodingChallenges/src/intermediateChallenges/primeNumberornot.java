//Author: Bongani Radebe
//Challenge: Determine whetheer a number is a prime or not

package helloWorld;

import java.util.ArrayList;

public class primeNumberornot {
	public static void main(String[] args) {
		ArrayList<Integer> factors_tacker1 = new ArrayList<Integer>(); //create an arraylist to store possible factors
		long sample_number = 782118877; 
		int i = 1;
			for(int j = 1; j <= sample_number; j++) {
				int x = i*j; //create a dummy product to determine if numbers going upto sample number actually divide it
				if(sample_number % x == 0 && x <= sample_number && j != 1) {//exclude obvious factor 1
					factors_tacker1.add(j); //add into arraylist of factors
				}
			
}
			
			
      System.out.println("factors: "+factors_tacker1);
      if(factors_tacker1.size() > 1) { //if number has more than 1 factor it isnt a prime
    	  System.out.println(sample_number+" is not a prime number");  
    	  
      }else {
    	  System.out.println(sample_number+" is a prime number");  
      }
}
}