package helloWorld;

public class armstrongNumbers {
	
public static void main(String[] args) {
		
		int number = 153;
				
		String number_string = String.valueOf(number);
		int sum = 0;
		for(int k = 0; k  < number_string.length(); k++) {
			
			sum += Math.pow(Character.getNumericValue(number_string.charAt(k)),number_string.length());
			
			
		}
		System.out.println(sum);
		
	}

}
