//Author: Bongani Radebe
//Challenge: Evaluate the loowest common factor of any two numbers 
package helloWorld;
import java.util.*;
import java.util.ArrayList;

public class lcfEvalualator {
	//lowest common factor calculator
	public static void main(String[] args) {
	ArrayList<Integer> factors_tacker1 = new ArrayList<Integer>();	
	ArrayList<Integer> factors_tacker2 = new ArrayList<Integer>();
	int number1 = 122180;
	int number2 = 871220;
	int i = 1;
	//for(int k = 1; k  <= number1; k++) {
		for(int j = 1; j <= number1; j++) {
			int x = i*j;
			if(number1 % x == 0 && x <= number1 && j != 1) {
				//factors_tacker.add(i);
				factors_tacker1.add(j);
			}
		}
		for(int j = 1; j <= number2;j++) {
			int x = i*j;
			if(number2 % x == 0 && x <= number2 && j != 1) {
				//factors_tacker.add(i);
				
				factors_tacker2.add(j);
			}
		}
		
		Set<Integer> set1 = new HashSet<>(factors_tacker1);
		Set<Integer> set2 = new HashSet<>(factors_tacker2);
		set1.retainAll(set2);
		ArrayList<Integer> intersection = new ArrayList<Integer>(set1);
		if(!intersection.isEmpty()) {
		int lcf = Collections.min(intersection);
		System.out.println("factors1: "+factors_tacker1);
		System.out.println("factors2: "+factors_tacker2);
		System.out.println("lcf: "+lcf);
		}else {
			int lcf = 0;
			System.out.println("factors1: "+factors_tacker1);
			System.out.println("factors2: "+factors_tacker2);
			System.out.println("No common factors");
			System.out.println("lcf: "+lcf);
		}
	//}
	

}
}