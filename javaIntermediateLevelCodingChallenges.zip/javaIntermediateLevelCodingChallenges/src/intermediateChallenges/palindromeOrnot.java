//Author: Bongani Radebe
//Challenge: Determine whether a word is a palindrome or not
package helloWorld;

public class palindromeOrnot {
	public static void main(String[] args) {
		String word = "viv";
		String word_campare = "";
		if(word.length() > 1) {
		for(int j = word.length() - 1; j >= 0; j--) {
			word_campare += word.charAt(j);
		}if(word.equals(word_campare)) {
			System.out.println(word+" is a palindrome");
		}else {
			System.out.println(word+" is a NOT palindrome");
		}
		
		}else {
			System.out.println("Please enter a word that is longer than 1 letter");
		}
		
	}
}
