//Author: Bongani Radebe
//Challenge: Reverse order of integer value
package helloWorld;


public class numberReverse {
	//output Reverse of an integer value
	public static void main(String[] args) {
		
		int number = 9876; //example integer
				
		String number_string = String.valueOf(number); //Convert integer to string
		String empty_string = ""; //Create a string i which to append chars in reverse order
		for(int k = number_string.length()-1; k  >= 0; k--) { //loop backwards
			empty_string += number_string.charAt(k);//Add chars into empty string
		}
		System.out.println(empty_string);
		
	}
	

}
