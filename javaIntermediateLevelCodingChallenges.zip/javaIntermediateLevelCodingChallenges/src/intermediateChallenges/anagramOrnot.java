package helloWorld;

public class anagramOrnot {
	public static void main(String[] args) {
		
		String word1 = "exact";
		String word2 = "txace";
		StringBuilder sb = new StringBuilder(word2);
		StringBuilder sb1 = new StringBuilder(word1);
		if(word1.length()==word2.length()) {
			for(int j = 0; j <= word1.length()-1; j++) {
				for(int k = 0; k  <= word1.length() - 1; k++) {
				if(word1.charAt(j) == sb.charAt(k)) {
				
					sb.setCharAt(k,'-');
					 System.out.println("word2: "+sb); 
			}
		}
		
	}
			
				for(int j = 0; j <= word2.length()-1; j++) {
					for(int k = 0; k  <= word2.length() - 1; k++) {
					if(word2.charAt(j) == sb1.charAt(k)) {
					
						sb1.setCharAt(k,'-');
						 System.out.println("word2: "+sb1); 
				}
			}
			
		}
			
			
			int dash_counter = 0;
			int dash_counter2 = 0;
			for(int j = 0; j <= sb.length()-1; j++) {
				if(sb.charAt(j) == '-') {
					dash_counter++;
					
			}
				
		
	}
			
			for(int j = 0; j <= sb1.length()-1; j++) {
				if(sb1.charAt(j) == '-') {
					dash_counter2++;
					
			}
			}
			if(dash_counter == sb.length() && dash_counter == dash_counter2) {
				System.out.println("dashes by dasher: "+dash_counter);
				System.out.println("dashes by dashee: "+dash_counter2);
				System.out.println("anagram:TRUE");
			}else {
				System.out.println("dashes by dasher: "+dash_counter);
				System.out.println("dashes by dashee: "+dash_counter2);
				System.out.println("anagram:FALSE");
			}
				
		
		
			
	}

		
		
}
}